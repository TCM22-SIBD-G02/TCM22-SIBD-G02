import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {Realizador} from '../models';
import {RealizadorRepository} from '../repositories';

export class RealizadorController {
  constructor(
    @repository(RealizadorRepository)
    public realizadorRepository : RealizadorRepository,
  ) {}

  @post('/realizadors')
  @response(200, {
    description: 'Realizador model instance',
    content: {'application/json': {schema: getModelSchemaRef(Realizador)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Realizador, {
            title: 'NewRealizador',
            exclude: ['idRealizador'],
          }),
        },
      },
    })
    realizador: Omit<Realizador, 'idRealizador'>,
  ): Promise<Realizador> {
    return this.realizadorRepository.create(realizador);
  }

  @get('/realizadors/count')
  @response(200, {
    description: 'Realizador model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Realizador) where?: Where<Realizador>,
  ): Promise<Count> {
    return this.realizadorRepository.count(where);
  }

  @get('/realizadors')
  @response(200, {
    description: 'Array of Realizador model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Realizador, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Realizador) filter?: Filter<Realizador>,
  ): Promise<Realizador[]> {
    return this.realizadorRepository.find(filter);
  }

  @patch('/realizadors')
  @response(200, {
    description: 'Realizador PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Realizador, {partial: true}),
        },
      },
    })
    realizador: Realizador,
    @param.where(Realizador) where?: Where<Realizador>,
  ): Promise<Count> {
    return this.realizadorRepository.updateAll(realizador, where);
  }

  @get('/realizadors/{id}')
  @response(200, {
    description: 'Realizador model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Realizador, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Realizador, {exclude: 'where'}) filter?: FilterExcludingWhere<Realizador>
  ): Promise<Realizador> {
    return this.realizadorRepository.findById(id, filter);
  }

  @patch('/realizadors/{id}')
  @response(204, {
    description: 'Realizador PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Realizador, {partial: true}),
        },
      },
    })
    realizador: Realizador,
  ): Promise<void> {
    await this.realizadorRepository.updateById(id, realizador);
  }

  @put('/realizadors/{id}')
  @response(204, {
    description: 'Realizador PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() realizador: Realizador,
  ): Promise<void> {
    await this.realizadorRepository.replaceById(id, realizador);
  }

  @del('/realizadors/{id}')
  @response(204, {
    description: 'Realizador DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.realizadorRepository.deleteById(id);
  }
}
