import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {Episodios} from '../models';
import {EpisodiosRepository} from '../repositories';

export class EpisodiosController {
  constructor(
    @repository(EpisodiosRepository)
    public episodiosRepository : EpisodiosRepository,
  ) {}

  @post('/episodios')
  @response(200, {
    description: 'Episodios model instance',
    content: {'application/json': {schema: getModelSchemaRef(Episodios)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Episodios, {
            title: 'NewEpisodios',
            exclude: ['idEpisodio'],
          }),
        },
      },
    })
    episodios: Omit<Episodios, 'idEpisodio'>,
  ): Promise<Episodios> {
    return this.episodiosRepository.create(episodios);
  }

  @get('/episodios/count')
  @response(200, {
    description: 'Episodios model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Episodios) where?: Where<Episodios>,
  ): Promise<Count> {
    return this.episodiosRepository.count(where);
  }

  @get('/episodios')
  @response(200, {
    description: 'Array of Episodios model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Episodios, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Episodios) filter?: Filter<Episodios>,
  ): Promise<Episodios[]> {
    return this.episodiosRepository.find(filter);
  }

  @patch('/episodios')
  @response(200, {
    description: 'Episodios PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Episodios, {partial: true}),
        },
      },
    })
    episodios: Episodios,
    @param.where(Episodios) where?: Where<Episodios>,
  ): Promise<Count> {
    return this.episodiosRepository.updateAll(episodios, where);
  }

  @get('/episodios/{id}')
  @response(200, {
    description: 'Episodios model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Episodios, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Episodios, {exclude: 'where'}) filter?: FilterExcludingWhere<Episodios>
  ): Promise<Episodios> {
    return this.episodiosRepository.findById(id, filter);
  }

  @patch('/episodios/{id}')
  @response(204, {
    description: 'Episodios PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Episodios, {partial: true}),
        },
      },
    })
    episodios: Episodios,
  ): Promise<void> {
    await this.episodiosRepository.updateById(id, episodios);
  }

  @put('/episodios/{id}')
  @response(204, {
    description: 'Episodios PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() episodios: Episodios,
  ): Promise<void> {
    await this.episodiosRepository.replaceById(id, episodios);
  }

  @del('/episodios/{id}')
  @response(204, {
    description: 'Episodios DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.episodiosRepository.deleteById(id);
  }
}
