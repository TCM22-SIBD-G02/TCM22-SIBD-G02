import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {AtoresSeries} from '../models';
import {AtoresSeriesRepository} from '../repositories';

export class AtoresSeriesController {
  constructor(
    @repository(AtoresSeriesRepository)
    public atoresSeriesRepository : AtoresSeriesRepository,
  ) {}

  @post('/atores-series')
  @response(200, {
    description: 'AtoresSeries model instance',
    content: {'application/json': {schema: getModelSchemaRef(AtoresSeries)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(AtoresSeries, {
            title: 'NewAtoresSeries',
            exclude: ['idSerie'],
          }),
        },
      },
    })
    atoresSeries: Omit<AtoresSeries, 'idSerie'>,
  ): Promise<AtoresSeries> {
    return this.atoresSeriesRepository.create(atoresSeries);
  }

  @get('/atores-series/count')
  @response(200, {
    description: 'AtoresSeries model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(AtoresSeries) where?: Where<AtoresSeries>,
  ): Promise<Count> {
    return this.atoresSeriesRepository.count(where);
  }

  @get('/atores-series')
  @response(200, {
    description: 'Array of AtoresSeries model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(AtoresSeries, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(AtoresSeries) filter?: Filter<AtoresSeries>,
  ): Promise<AtoresSeries[]> {
    return this.atoresSeriesRepository.find(filter);
  }

  @patch('/atores-series')
  @response(200, {
    description: 'AtoresSeries PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(AtoresSeries, {partial: true}),
        },
      },
    })
    atoresSeries: AtoresSeries,
    @param.where(AtoresSeries) where?: Where<AtoresSeries>,
  ): Promise<Count> {
    return this.atoresSeriesRepository.updateAll(atoresSeries, where);
  }

  @get('/atores-series/{id}')
  @response(200, {
    description: 'AtoresSeries model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(AtoresSeries, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(AtoresSeries, {exclude: 'where'}) filter?: FilterExcludingWhere<AtoresSeries>
  ): Promise<AtoresSeries> {
    return this.atoresSeriesRepository.findById(id, filter);
  }

  @patch('/atores-series/{id}')
  @response(204, {
    description: 'AtoresSeries PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(AtoresSeries, {partial: true}),
        },
      },
    })
    atoresSeries: AtoresSeries,
  ): Promise<void> {
    await this.atoresSeriesRepository.updateById(id, atoresSeries);
  }

  @put('/atores-series/{id}')
  @response(204, {
    description: 'AtoresSeries PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() atoresSeries: AtoresSeries,
  ): Promise<void> {
    await this.atoresSeriesRepository.replaceById(id, atoresSeries);
  }

  @del('/atores-series/{id}')
  @response(204, {
    description: 'AtoresSeries DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.atoresSeriesRepository.deleteById(id);
  }
}
