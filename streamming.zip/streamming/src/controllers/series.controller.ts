import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {Series} from '../models';
import {SeriesRepository} from '../repositories';

export class SeriesController {
  constructor(
    @repository(SeriesRepository)
    public seriesRepository : SeriesRepository,
  ) {}

  @post('/series')
  @response(200, {
    description: 'Series model instance',
    content: {'application/json': {schema: getModelSchemaRef(Series)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Series, {
            title: 'NewSeries',
            exclude: ['idSeries'],
          }),
        },
      },
    })
    series: Omit<Series, 'idSeries'>,
  ): Promise<Series> {
    return this.seriesRepository.create(series);
  }

  @get('/series/count')
  @response(200, {
    description: 'Series model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Series) where?: Where<Series>,
  ): Promise<Count> {
    return this.seriesRepository.count(where);
  }

  @get('/series')
  @response(200, {
    description: 'Array of Series model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Series, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Series) filter?: Filter<Series>,
  ): Promise<Series[]> {
    return this.seriesRepository.find(filter);
  }

  @patch('/series')
  @response(200, {
    description: 'Series PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Series, {partial: true}),
        },
      },
    })
    series: Series,
    @param.where(Series) where?: Where<Series>,
  ): Promise<Count> {
    return this.seriesRepository.updateAll(series, where);
  }

  @get('/series/{id}')
  @response(200, {
    description: 'Series model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Series, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Series, {exclude: 'where'}) filter?: FilterExcludingWhere<Series>
  ): Promise<Series> {
    return this.seriesRepository.findById(id, filter);
  }

  @patch('/series/{id}')
  @response(204, {
    description: 'Series PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Series, {partial: true}),
        },
      },
    })
    series: Series,
  ): Promise<void> {
    await this.seriesRepository.updateById(id, series);
  }

  @put('/series/{id}')
  @response(204, {
    description: 'Series PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() series: Series,
  ): Promise<void> {
    await this.seriesRepository.replaceById(id, series);
  }

  @del('/series/{id}')
  @response(204, {
    description: 'Series DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.seriesRepository.deleteById(id);
  }
}
