import {Entity, model, property} from '@loopback/repository';

@model()
export class AtoresSeries extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  idSerie?: number;

  @property({
    type: 'number',
    required: true,
  })
  idAtores: number;


  constructor(data?: Partial<AtoresSeries>) {
    super(data);
  }
}

export interface AtoresSeriesRelations {
  // describe navigational properties here
}

export type AtoresSeriesWithRelations = AtoresSeries & AtoresSeriesRelations;
