import {Entity, model, property} from '@loopback/repository';

@model()
export class Atores extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  idAtores?: number;

  @property({
    type: 'string',
    required: true,
  })
  nomeAtor: string;


  constructor(data?: Partial<Atores>) {
    super(data);
  }
}

export interface AtoresRelations {
  // describe navigational properties here
}

export type AtoresWithRelations = Atores & AtoresRelations;
