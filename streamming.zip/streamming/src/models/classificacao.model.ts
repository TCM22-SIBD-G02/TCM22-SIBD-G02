import {Entity, model, property} from '@loopback/repository';

@model()
export class Classificacao extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  idClassificacao?: number;

  @property({
    type: 'number',
    required: true,
  })
  idConteudo: number;

  @property({
    type: 'string',
    required: true,
  })
  Duracao: string;

  @property({
    type: 'number',
    required: true,
  })
  gosto: number;

  @property({
    type: 'number',
    required: true,
  })
  Dislike: number;


  constructor(data?: Partial<Classificacao>) {
    super(data);
  }
}

export interface ClassificacaoRelations {
  // describe navigational properties here
}

export type ClassificacaoWithRelations = Classificacao & ClassificacaoRelations;
