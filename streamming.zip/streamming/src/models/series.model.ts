import {Entity, model, property} from '@loopback/repository';

@model()
export class Series extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  idSeries?: number;

  @property({
    type: 'number',
    required: true,
  })
  Temporada: number;

  @property({
    type: 'number',
    required: true,
  })
  idConteudo: number;


  constructor(data?: Partial<Series>) {
    super(data);
  }
}

export interface SeriesRelations {
  // describe navigational properties here
}

export type SeriesWithRelations = Series & SeriesRelations;
