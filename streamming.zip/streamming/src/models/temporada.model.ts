import {Entity, model, property} from '@loopback/repository';

@model()
export class Temporada extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  idTemporada?: number;

  @property({
    type: 'number',
    required: true,
  })
  idSeries: number;

  @property({
    type: 'number',
    required: true,
  })
  anoProducao: number;

  @property({
    type: 'string',
    required: true,
  })
  Classificacao: string;


  constructor(data?: Partial<Temporada>) {
    super(data);
  }
}

export interface TemporadaRelations {
  // describe navigational properties here
}

export type TemporadaWithRelations = Temporada & TemporadaRelations;
