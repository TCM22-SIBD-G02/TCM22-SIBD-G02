import {Entity, model, property} from '@loopback/repository';

@model()
export class Episodios extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  idEpisodio?: number;

  @property({
    type: 'string',
    required: true,
  })
  Titulo: string;

  @property({
    type: 'string',
    required: true,
  })
  Duracao: string;

  @property({
    type: 'number',
    required: true,
  })
  idSerie: number;


  constructor(data?: Partial<Episodios>) {
    super(data);
  }
}

export interface EpisodiosRelations {
  // describe navigational properties here
}

export type EpisodiosWithRelations = Episodios & EpisodiosRelations;
