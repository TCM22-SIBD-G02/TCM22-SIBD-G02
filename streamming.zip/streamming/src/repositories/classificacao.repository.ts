import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {G02DataSource} from '../datasources';
import {Classificacao, ClassificacaoRelations} from '../models';

export class ClassificacaoRepository extends DefaultCrudRepository<
  Classificacao,
  typeof Classificacao.prototype.idClassificacao,
  ClassificacaoRelations
> {
  constructor(
    @inject('datasources.g02') dataSource: G02DataSource,
  ) {
    super(Classificacao, dataSource);
  }
}
