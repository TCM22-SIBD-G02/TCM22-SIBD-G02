import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {G02DataSource} from '../datasources';
import {Series, SeriesRelations} from '../models';

export class SeriesRepository extends DefaultCrudRepository<
  Series,
  typeof Series.prototype.idSeries,
  SeriesRelations
> {
  constructor(
    @inject('datasources.g02') dataSource: G02DataSource,
  ) {
    super(Series, dataSource);
  }
}
