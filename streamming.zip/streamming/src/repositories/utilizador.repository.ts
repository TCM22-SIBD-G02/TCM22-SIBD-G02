import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {G02DataSource} from '../datasources';
import {Utilizador, UtilizadorRelations} from '../models';

export class UtilizadorRepository extends DefaultCrudRepository<
  Utilizador,
  typeof Utilizador.prototype.idUtilizador,
  UtilizadorRelations
> {
  constructor(
    @inject('datasources.g02') dataSource: G02DataSource,
  ) {
    super(Utilizador, dataSource);
  }
}
