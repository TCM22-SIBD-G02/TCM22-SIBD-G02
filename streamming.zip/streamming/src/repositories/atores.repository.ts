import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {G02DataSource} from '../datasources';
import {Atores, AtoresRelations} from '../models';

export class AtoresRepository extends DefaultCrudRepository<
  Atores,
  typeof Atores.prototype.idAtores,
  AtoresRelations
> {
  constructor(
    @inject('datasources.g02') dataSource: G02DataSource,
  ) {
    super(Atores, dataSource);
  }
}
