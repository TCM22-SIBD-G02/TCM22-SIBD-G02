import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {G02DataSource} from '../datasources';
import {Temporada, TemporadaRelations} from '../models';

export class TemporadaRepository extends DefaultCrudRepository<
  Temporada,
  typeof Temporada.prototype.idTemporada,
  TemporadaRelations
> {
  constructor(
    @inject('datasources.g02') dataSource: G02DataSource,
  ) {
    super(Temporada, dataSource);
  }
}
