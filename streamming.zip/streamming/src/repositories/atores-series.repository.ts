import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {G02DataSource} from '../datasources';
import {AtoresSeries, AtoresSeriesRelations} from '../models';

export class AtoresSeriesRepository extends DefaultCrudRepository<
  AtoresSeries,
  typeof AtoresSeries.prototype.idSerie,
  AtoresSeriesRelations
> {
  constructor(
    @inject('datasources.g02') dataSource: G02DataSource,
  ) {
    super(AtoresSeries, dataSource);
  }
}
