import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {G02DataSource} from '../datasources';
import {Episodios, EpisodiosRelations} from '../models';

export class EpisodiosRepository extends DefaultCrudRepository<
  Episodios,
  typeof Episodios.prototype.idEpisodio,
  EpisodiosRelations
> {
  constructor(
    @inject('datasources.g02') dataSource: G02DataSource,
  ) {
    super(Episodios, dataSource);
  }
}
