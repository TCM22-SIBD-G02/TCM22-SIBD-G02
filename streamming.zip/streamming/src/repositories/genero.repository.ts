import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {G02DataSource} from '../datasources';
import {Genero, GeneroRelations} from '../models';

export class GeneroRepository extends DefaultCrudRepository<
  Genero,
  typeof Genero.prototype.idgenero,
  GeneroRelations
> {
  constructor(
    @inject('datasources.g02') dataSource: G02DataSource,
  ) {
    super(Genero, dataSource);
  }
}
